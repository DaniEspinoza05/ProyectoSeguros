<footer>
    <p>&copy; 2024 SaveMe - Todos los derechos reservados</p>
    <p><a href="privacidad.php">Política de privacidad</a> | <a href="terminos.php">Términos y condiciones</a></p>
    <p>Teléfono: +123 456 789 | Email: contacto@save-me.com</p>
    <p>
        <a href="https://www.facebook.com/SaveMe" target="_blank">Facebook</a> |
        <a href="https://twitter.com/SaveMe" target="_blank">Twitter</a> |
        <a href="https://www.instagram.com/SaveMe" target="_blank">Instagram</a>
    </p>
</footer>
